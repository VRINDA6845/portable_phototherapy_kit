import 'package:flutter/material.dart';
import 'screens/dashboard.dart';
import 'screens/how_to_use.dart';
import 'screens/protocols.dart';
import 'screens/maintenance_screen.dart';

void main() {
  runApp(const PhototherapyApp());
}

class PhototherapyApp extends StatelessWidget {
  const PhototherapyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Phototherapy Kit',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF001F3F),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00BCD4),
          secondary: Color(0xFF003366),
        ),
        textTheme: ThemeData.dark().textTheme.apply(
              fontFamily: 'Poppins',
              bodyColor: Colors.white,
            ),
      ),
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;

  // All 4 screens in your app
  final List<Widget> _screens = const [
    DashboardScreen(),
    HowItWorksScreen(),
    ProtocolsScreen(),
    MaintenanceScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF00264D),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF00E5FF),
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.light_mode),
            label: 'How It Works',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.warning),
            label: 'Protocols',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Maintenance',
          ),
        ],
      ),
    );
  }
}
