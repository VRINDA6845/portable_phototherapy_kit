import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HowItWorksScreen extends StatelessWidget {
  const HowItWorksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001F3F), // dark blue base
      appBar: AppBar(
        backgroundColor: const Color(0xFF006D77),
        title: Text(
          "Phototherapy: Mechanism & Usage",
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildInfoCard(
              icon: Icons.baby_changing_station,
              title: "1. What is Jaundice (Hyperbilirubinemia)?",
              description:
                  "Jaundice (Neonatal Hyperbilirubinemia) is a common condition in newborns caused by high levels of a yellow pigment called **Bilirubin** in the blood. Bilirubin is produced from the normal breakdown of red blood cells. A mature liver typically filters it out, but a newborn's liver is often underdeveloped, leading to bilirubin accumulation. Untreated high bilirubin can be toxic to the brain.",
            ),
            _buildInfoCard(
              icon: Icons.medical_information,
              title: "2. The Scientific Treatment for Neonatal Jaundice",
              description:
                  "Phototherapy is a non-invasive and highly effective treatment. The special **blue light** (typically 460 to 490 nm wavelength) converts bilirubin into forms that the baby’s body can directly excrete through urine and stool, without liver processing. This process, called **Photoisomerization**, is the fastest method to transform bilirubin into a non-toxic, excretable form.",
            ),
            _buildInfoCard(
              icon: Icons.light,
              title: "3. Our Portable Umbrella Phototherapy Device",
              description:
                  "Our device is an innovative **foldable phototherapy system** designed for home use or limited-resource settings.\n\n"
                  "**Design:** It consists of a robust main body and stand supporting the light-emitting umbrella.\n\n"
                  "**Operation:** The height of the umbrella is adjusted to the optimal distance from the baby using a linear actuator, operated through a **DPDT (Double Pole Double Throw)** switch. By reversing voltage polarity, the umbrella smoothly opens and closes, ensuring accurate light intensity toward the baby.",
            ),
            _buildInfoCard(
              icon: Icons.fact_check,
              title: "4. Essential Device Usage Steps",
              description:
                  "**Step 1: Set Up the Device**\nPlace the stand on a flat, stable surface next to the baby’s crib/cradle. Turn on the power.\n\n"
                  "**Step 2: Adjust Height**\nSet umbrella height to 35–45 cm from the baby.\n\n"
                  "**Step 3: Prepare the Baby**\nUse **eye shields** and dress only in a diaper for full skin exposure.\n\n"
                  "**Step 4: Set Intensity**\nAdjust the dimmer switch to the doctor’s suggested level.\n\n"
                  "**Step 5: Start Treatment**\nMonitor temperature, turn the baby every 2–3 hours.\n\n"
                  "**Caution:** Ensure the baby does not overheat and is fed every 2–4 hours to flush out bilirubin quickly.",
            ),
            const SizedBox(height: 20),
            Text(
              "Refer to the 'Protocols' tab for detailed information and safety guidelines.",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 13,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF002B5B),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: const Offset(2, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.cyanAccent, size: 26),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.poppins(
                    color: Colors.cyanAccent,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            description,
            style: GoogleFonts.openSans(
              color: Colors.white,
              fontSize: 14.5,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
