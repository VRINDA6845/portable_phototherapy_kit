import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MaintenanceScreen extends StatelessWidget {
  const MaintenanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001F3F), // Deep blue background
      appBar: AppBar(
        backgroundColor: const Color(0xFF006D77),
        title: Text(
          'Device Maintenance & Care',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildSection(
              icon: Icons.cleaning_services_rounded,
              title: '1. Cleaning & Hygiene',
              content: '''
Proper cleaning ensures maximum light transmission and minimizes infection risk.

• **Light Umbrella:** Wipe the inside surface with a soft cloth dampened with mild, non-abrasive solution (70% isopropyl alcohol).
• **Main Stand/Base:** Wipe with a hospital-grade disinfectant wipe. Ensure dry surfaces before use.
• **Frequency:** Clean after every use or weekly during continuous operation.
''',
            ),
            buildSection(
              icon: Icons.wb_sunny_rounded,
              title: '2. Light Efficacy & Replacement',
              content: '''
LED effectiveness decreases over time, reducing treatment quality.

• **Efficacy Check:** LEDs are rated for approximately 20,000 hours of use.
• **Visual Check:** Inspect all LED strips monthly. Contact support if dim or failed.
• **Replacement:** Only use manufacturer-approved LED replacements.
''',
            ),
            buildSection(
              icon: Icons.precision_manufacturing_rounded,
              title: '3. Mechanical & Actuator Safety',
              content: '''
The linear actuator controls height; handle it with care.

• **Actuator Check:** Periodically check for smooth operation. Listen for unusual grinding.
• **Cables:** Inspect for frays or damage. Replace immediately if needed.
• **Stability:** Ensure base is stable and on a non-slip surface.
''',
            ),
            buildSection(
              icon: Icons.storage_rounded,
              title: '4. Storage & Transport',
              content: '''
When not in use, safely fold and store the device.

• **Storage:** Keep in protective case away from sunlight, moisture, and heat.
• **Transport:** Handle with care to avoid mechanical stress or shocks.
''',
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSection({
    required IconData icon,
    required String title,
    required String content,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF012A4A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.cyanAccent.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
            color: Colors.blueAccent.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.cyanAccent, size: 24),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.poppins(
                    color: Colors.cyanAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Divider(color: Colors.white24),
          const SizedBox(height: 8),
          Text(
            content,
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.9),
              fontSize: 14,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}
