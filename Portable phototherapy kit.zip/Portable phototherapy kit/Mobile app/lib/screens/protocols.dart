import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProtocolsScreen extends StatelessWidget {
  const ProtocolsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001F3F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF003366),
        title: Text(
          "Safety Protocols & Optimal Values",
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildProtocolCard(
              context,
              title: "1. Temperature Protocol (Thermoregulation)",
              icon: Icons.thermostat,
              color: Colors.cyanAccent,
              description:
                  "Maintaining a stable thermal environment is essential during phototherapy, as light exposure may cause heating or cooling issues. The system must keep the temperature within the optimal range to ensure baby safety.",
              content: [
                "✅ Optimal Temperature Range: 45°C – 55°C",
                "",
                "🩺 Action Steps:",
                "- If temperature is below 45°C, increase heater intensity and monitor until stable.",
                "- If temperature exceeds 55°C, stop the light source immediately and allow the system to cool down.",
                "- Regularly monitor temperature every 3–4 hours or more frequently if unstable.",
                "[Source: Device Safety Guidelines]",
              ],
            ),
            const SizedBox(height: 20),
            _buildProtocolCard(
              context,
              title: "2. Light Intensity Protocol (Irradiance)",
              icon: Icons.light_mode,
              color: Colors.lightBlueAccent,
              description:
                  "The light intensity determines the effectiveness of phototherapy. Proper calibration ensures safe and efficient bilirubin breakdown.",
              content: [
                "💡 Optimal Wavelength: Blue-green light, 460–490 nm (LED based)",
                "☀️ Standard Phototherapy: 8–10 µW/cm²/nm",
                "🌞 Intensive Phototherapy: 30 µW/cm²/nm or higher",
                "✏️ Maintain a distance of 35–45 cm between the light and the baby for uniform exposure.",
                "[Source: AAP Technical Report]",
              ],
            ),
            const SizedBox(height: 20),
            _buildProtocolCard(
              context,
              title: "3. Essential Safety Checklist",
              icon: Icons.shield,
              color: Colors.tealAccent,
              description: "",
              content: [
                "🧍 Exposure: Maximize skin exposure (diaper only). Rotate the baby every 2–3 hours.",
                "😎 Eye Protection: Use opaque shields during therapy; remove only for feeding or cuddling.",
                "💧 Hydration: Ensure frequent feeding every 2–4 hours to prevent dehydration.",
                "🧸 Fluid Output: Monitor urination and stool output regularly; report low output immediately.",
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProtocolCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required String description,
    required List<String> content,
  }) {
    return Card(
      color: const Color(0xFF002B5B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 6,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (description.isNotEmpty)
              Text(
                description,
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 14,
                ),
              ),
            const SizedBox(height: 10),
            for (var line in content)
              Text(
                line,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 14,
                  height: 1.5,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
