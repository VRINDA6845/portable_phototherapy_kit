import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  double lux = 0;
  double temp = 0;
  bool overTemp = false;
  Timer? timer;
  bool isConnected = false;
  String errorMessage = "";

  // ESP32 AP IP
  final String espUrl = "http://192.168.4.1/status";

  @override
  void initState() {
    super.initState();
    fetchData();
    timer = Timer.periodic(const Duration(seconds: 1), (timer) => fetchData());
  }

  Future<void> fetchData() async {
    try {
      final response = await http.get(Uri.parse(espUrl)).timeout(
        const Duration(seconds: 5), // Increased timeout
      );
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          // Handle lux - check for invalid value
          double luxValue = (data["lux"] ?? -1).toDouble();
          lux = luxValue >= 0 ? luxValue : 0;
          
          // Handle temp - check for invalid value (-999)
          double tempValue = (data["temp"] ?? -999).toDouble();
          temp = tempValue != -999 ? tempValue : 0;
          
          // Handle over-temp flag
          overTemp = (data["over"] ?? 0) == 1;
          
          isConnected = true;
          errorMessage = "";
        });
        
        // Debug print
        print("✅ Data received: lux=$lux, temp=$temp, over=$overTemp");
      } else {
        setState(() {
          isConnected = false;
          errorMessage = "HTTP ${response.statusCode}";
        });
        print("❌ HTTP Error: ${response.statusCode}");
      }
    } catch (e) {
      setState(() {
        isConnected = false;
        errorMessage = e.toString();
      });
      print("❌ Connection Error: $e");
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Color getStatusColor() {
    if (!isConnected) return Colors.grey;
    if (overTemp) return Colors.redAccent;
    if (temp >= 45) return Colors.orangeAccent;
    return Colors.greenAccent;
  }

  String getStatusText() {
    if (!isConnected) return "Disconnected";
    if (overTemp) return "Over Temperature!";
    if (temp >= 45) return "High Temperature";
    return "Normal";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001F3F),
      appBar: AppBar(
        title: const Text("Phototherapy Dashboard"),
        backgroundColor: const Color(0xFF00264D),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildCard("Lux Intensity", lux.toStringAsFixed(1), "lx"),
            const SizedBox(height: 20),
            _buildCard("Temperature", temp.toStringAsFixed(2), "°C"),
            const SizedBox(height: 20),
            _buildStatusCard(),
            const SizedBox(height: 40),
            _buildConnectionNotice(),
            // Debug info (remove in production)
            if (errorMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Text(
                  "Debug: $errorMessage",
                  style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(String title, String value, String unit) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF003366),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 10)],
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(fontSize: 18, color: Colors.white70)),
          const SizedBox(height: 10),
          Text(
            "$value $unit",
            style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.cyanAccent),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF003366),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 10)],
      ),
      child: Column(
        children: [
          const Text("System Status", style: TextStyle(fontSize: 18, color: Colors.white70)),
          const SizedBox(height: 10),
          Text(
            getStatusText(),
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: getStatusColor()),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectionNotice() {
    return Column(
      children: [
        Icon(
          isConnected ? Icons.wifi : Icons.wifi_off,
          size: 40,
          color: isConnected ? Colors.greenAccent : Colors.white70,
        ),
        const SizedBox(height: 10),
        Text(
          isConnected
              ? "✅ Connected to Phototherapy Device"
              : "⚠️ Connect to Wi-Fi 'Phototherapy' (password: photokit123)",
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isConnected ? Colors.greenAccent : Colors.white70,
            fontWeight: isConnected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }
}