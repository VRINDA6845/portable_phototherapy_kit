package com.example.phototherapy_monitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
